<?php
	get_header();
		include(ENOVATHEMES_ADDONS.'project/content-project-header.php');
		include(ENOVATHEMES_ADDONS.'project/content-project-single.php');
	get_footer(); 
?>